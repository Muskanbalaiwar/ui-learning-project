import { useState } from "react";
import "./App.css";

const slides = [
  "Slide 1 Content",
  "Slide 2 Content",
  "Slide 3 Content",
];

function App() {
 const [ open , setOpen] = useState(false)
 const [activeBar , setActiveBar] = useState("Homesdfbfwebhfbhrjh")


  const [index, setIndex] = useState(0);

  const next = () => {
    setIndex((prev) => (prev + 1) % slides.length);
  };

  const prev = () => {
    setIndex((prev) =>
      prev === 0 ? slides.length - 1 : prev - 1
    );
  };

  return (
    <>
    {/* <div className="container">
      {
        Boxes.map((item,index)=>{
        return  (
          <div className="box" key ={index}>{item.name}</div>)
        })
      }
    </div> */}
    {/* <button className="button" onClick={()=>{setOpen(true)}}>click</button>
    <div className="accordion-container">
    <details className="accordion">
      <summary>what is flex box</summary>
      <hr/>
      <p>flex box is used to dynamically align boxes in row or column(in 1D)</p>
    </details>
       <details className="accordion">
      <summary >what is grid box</summary>
         <hr/>
      <p>grid box is used when layout looks like table or matrix(2D format). and it have properties as well</p>
    </details>
      <details className="accordion">
      <summary >what is grid box</summary>
      <p>grid box is used when layout looks like table or matrix(2D format). and it have properties as well</p>
    </details>
      <details className="accordion">
      <summary >what is grid box</summary>
      <p>grid box is used when layout looks like table or matrix(2D format). and it have properties as well</p>
    </details>
      <details className="accordion">
      <summary >what is grid box</summary>
      <p>grid box is used when layout looks like table or matrix(2D format). and it have properties as well</p>
    </details>
    </div>
   {
    open &&
    <div className="modal-overlay">
      <div className="modal">
        <div className="header">
      <div className="content"> Are You sure u want to confirm</div>
        </div>
        <div>
      <div className="body">
        <button onClick={()=>{setOpen(false)}} className="button">Yes</button>
        <button onClick={()=>{setOpen(false)}}  className="cancel-button">No</button>
      </div>
      </div>
      </div>
    </div>
   } */}
   {/* <div className ="sidebar-container">
    <div className={`item ${activeBar === "Homesdfbfwebhfbhrjh" ? "active" : ""}`} onClick={()=>{
      setActiveBar("Homesdfbfwebhfbhrjh")
     }}>Homesdfbfwebhfbhrjh</div>
     <div className={`item ${activeBar === "Dashboard" ? "active" : ""}`}onClick={()=>{
      setActiveBar("Dashboard")
     }}>Dashboard</div>
    <div className={`item ${activeBar === "About us" ? "active" : ""}`} onClick={()=>{
      setActiveBar("About us")
     }}>About us</div>
    <div className={`item ${activeBar === "settings" ? "active" : ""}`} onClick={()=>{
      setActiveBar("settings")
     }}>settings</div>
   </div> */}


     <div className="slider">
      <div
        className="slider-track"
        style={{ transform: `translateX(-${index * 100}%)` }}
      >
        {slides.map((slide, i) => (
          <div className="slide" key={i}>
            {slide}
          </div>
        ))}
      </div>

      <button onClick={prev}>◀</button>
      <button onClick={next}>▶</button>
    </div>
    </>
  );
}

export default App;
