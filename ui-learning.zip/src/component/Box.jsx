import React from 'react'

export const Box = () => {
  return (
    <div>Box</div>
  )
}
